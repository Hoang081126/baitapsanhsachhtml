const searchForm = document.getElementById('search-form');
const searchInput = document.getElementById('search');
const searchStatus = document.getElementById('search-status');
const sections = Array.from(document.querySelectorAll('main > section'));

searchForm.addEventListener('submit', function (event) {
    event.preventDefault();
    const query = searchInput.value.trim().toLowerCase();
    sections.forEach(section => section.classList.remove('search-match'));
    searchStatus.hidden = false;

    if (!query) {
        searchStatus.textContent = 'Please enter a search term.';
        searchInput.focus();
        return;
    }

    const matches = sections.filter(section => section.textContent.toLowerCase().includes(query));
    if (matches.length === 0) {
        searchStatus.textContent = 'No matching topic. Try HTML, C Programming or Java.';
        return;
    }

    matches.forEach(section => section.classList.add('search-match'));
    const heading = matches[0].querySelector('h1, h2');
    (heading || matches[0]).scrollIntoView({ block: 'start' });
    searchStatus.textContent = matches.length + ' matching section(s).';
});

searchInput.addEventListener('input', function () {
    searchStatus.hidden = true;
    sections.forEach(section => section.classList.remove('search-match'));
});
