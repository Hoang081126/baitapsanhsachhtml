# Simple Web Development Template

## Chạy bài

Mở index.html bằng trình duyệt. Logo và ảnh đã có trong thư mục images; trang không phụ thuộc thư viện hoặc font trực tuyến.

## Nội dung

- Navbar nền đen, logo và các liên kết Web Technology, C Programming, Courses.
- Hai section nền xanh lá và xanh dương, giữ nội dung chính của đề bài.
- Section Java có văn bản bên trái và ảnh laptop bên phải.
- Footer nền đen, chữ trắng.
- Thanh điều hướng sticky; bố cục thích ứng với màn hình nhỏ.
- Tìm kiếm trong nội dung ba section bằng JavaScript, không gửi dữ liệu ra bên ngoài.

## Các điểm đã sửa từ mã mẫu

- Đồng nhất rightNav giữa HTML và CSS.
- Đặt logo trong li để danh sách điều hướng có cấu trúc hợp lệ.
- Thêm id="course" để liên kết Courses có đích đến.
- Dùng min-height thay cho chiều cao cố định, tránh cắt nội dung khi màn hình nhỏ.
- Cho .secondHalf rộng 100% vì phần này chứa đoạn văn.
- Đổi chữ trên nền xanh thành màu trắng để dễ đọc.
- Dùng h1 cho tiêu đề chính và h2 cho các phần sau.

CSS đã có .section-Left với flex-direction: row-reverse. Có thể thêm class này vào section Java để chuyển ảnh sang trái trên màn hình rộng; màn hình nhỏ vẫn xếp dọc.

## Kiểm tra

1. Nhấn từng liên kết điều hướng để đến đúng nội dung.
2. Tìm HTML hoặc Java; thử một từ không có trong nội dung.
3. Thu nhỏ cửa sổ để kiểm tra menu, nội dung và hình ảnh không bị tràn ngang.
4. Cuộn xuống để kiểm tra thanh điều hướng sticky.

## Nộp GitHub

Giải nén ZIP. Trong repository Hoang081126/baitapsanhsachhtml chọn Add file, Upload files, kéo cả thư mục simple-web-template vào rồi Commit changes. Dùng link repository để nộp bài.

## Nguồn ảnh

Ảnh laptop: Jon Sullivan (PD Photo.org), public domain.
Trang nguồn: https://commons.wikimedia.org/wiki/File:Laptop.jpg
Logo là hình SVG được tạo bằng mã cho bài thực hành.
